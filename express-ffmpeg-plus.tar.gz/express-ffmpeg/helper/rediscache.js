var redis = require('redis');
var client = redis.createClient();
var jwt = require('jsonwebtoken');
var Setting = require('../models/setting');
var Movie = require('../models/movie');
var Tv = require('../models/tv');
const Article = require('../models/article');
var Push = require('../models/push');
var _ = require('lodash');
var async = require('async');
exports.getIndexByRedis = function(cb) {
  getIndexFromRedis(function(err, results) {
    if(err) {
      console.log(err);
    }
    if(!results) {
      getIndexFromMongo(function(err, results) {
        if(err) {
          console.log(err);
        }
        return cb(null, results);
      })
    } else {
      return cb(null, results);
    }
  })
}
function getIndexFromRedis(cb) {
  client.get('index', function(err, results) {
    if (err) {
      console.log(err);
    }
    return cb(err, JSON.parse(results));
  });
}
async function getIndexFromMongo(cb) {
  const perPage = 10;
  const results = {};
  const now = new Date();
  const month = new Date(now.getTime() - 30 * 24 * 3600 * 1000);
  const pushmovies = await Push.find().sort('-createAt').limit(6).populate('movieid');
  const hotmovies = await Movie.find({status: 'finished'}).where('createAt').gt(month).sort('-count').limit(perPage);
  const hottvs = await Tv.find().where('createAt').gt(month).sort('-count').limit(perPage);
  const newmovies = await Movie.find({status: 'finished'}).sort('-createAt').limit(perPage);
  const newtvs = await Tv.find().sort('-createAt').limit(perPage);
  const news = await Article.find().sort('-createAt').limit(perPage);
  results.pushmovies = pushmovies;
  results.hotmovies = hotmovies;
  results.hottvs = hottvs;
  results.newmovies = newmovies;
  results.newtvs = newtvs;
  results.news = news;
  client.setex('index', 3600, JSON.stringify(results));
  return cb(null, results);
}
exports.apiGetMoviesByRedis = function(tag, cb) {
  apiGetMoviesFromRedis(tag, function(err, results) {
    if(err) {
      console.log(err);
    }
    if(!results) {
      apiGetMoviesFromMongo(tag, function(err, results) {
        if(err) {
          console.log(err);
        }
        return cb(null, results);
      })
    } else {
      return cb(null, results);
    }
  })
}
function apiGetMoviesFromRedis(tag, cb) {
  client.get('movies:' + tag, function(err, results) {
    if (err) {
      console.log(err);
    }
    return cb(err, JSON.parse(results));
  });
}
async function apiGetMoviesFromMongo(tag, cb) {
  let find = {};
  if(tag != '精选') {
    find = {$or: [
      { director: tag },
      { stars: tag },
      { writer: tag },
      { country: tag },
      { tags: tag }
    ]};
  }
  let perPage = 20;
  const now = new Date();
  const start = new Date(now.getTime() - 90 * 24 * 3600 * 1000);
  const moviescount = await Movie.countDocuments(find).where({status: 'finished'});
  const tvcount = await Tv.countDocuments(find);
  let movieskip = Math.floor(Math.random() * (moviescount - 2));
  let tvskip = Math.floor(Math.random * (tvcount -2 ));
  const tvfind = {'episodes.0': {$exists: 1}};
  if (movieskip < 0) {
    movieskip = 0;
  }
  if (tvskip < 0) {
    tvskip = 0;
  }
  async.parallel(
    {
      randommovies: function(callback) {
        Movie.find(find)
          .where({status: 'finished'})
          .limit(2)
          .skip(movieskip)
          .exec(function(err, movies) {
            if(err) {
              console.log(err);
            }
            callback(null, movies);
          })
      },
      randomtvs: function(callback) {
        Tv.find(find)
          .where(tvfind)
          .limit(2)
          .skip(tvskip)
          .exec(function(err, tvs) {
            if(err) {
              console.log(err);
            }
            callback(null, tvs);
          })
      },
      hotmovies: function(callback) {
        Movie.find({status: 'finished'})
          .where('createAt').gt(start)
          .where(find)
          .sort('-count')
          .limit(2)
          .exec(function(err, movies) {
            if(err) {
              console.log(err);
            }
            callback(null, movies);
          })
      },
      hottvs: function(callback) {
        Tv.find(find)
          .where('createAt').gt(start)
          .where(tvfind)
          .sort('-count')
          .limit(2)
          .exec(function(err, tvs) {
            if(err) {
              console.log(err)
            }
            callback(null, tvs);
          })
      },
      movies: function(callback) {
        Movie.find({ status: 'finished'})
          .where(find)
          .sort('-createAt')
          .limit(perPage)
          .exec(function(err, movies) {
            if (err) {
              console.log(err);
            }
            callback(null, movies);
          });
      },
      pushmovies: function(callback) {
        Push.find()
          .sort('-createAt')
          .limit(5)
          .populate('movieid')
          .exec(function(err, pushmovies) {
            if (err) {
              console.log(err);
            }
            callback(null, pushmovies);
          });
      },
      tvs: function(callback) {
        Tv.find(find)
          .where(tvfind)
          .sort('-createAt')
          .limit(perPage)
          .exec(function(err, tvs) {
            if (err) {
              console.log(err);
            }
            callback(null, tvs);
          });
      }
    },
    function(err, results) {
      if (err) {
        console.log(err);
      }
      client.setex('movies:' + tag, 3600, JSON.stringify(results));
      return cb(err, results);
    }
  );
}
exports.getTokenByRedis = function(cb) {
  getTokenFromRedis(function(err, token) {
    if (err) {
      console.log(err);
    }
    if (!token) {
      getMoviesFromJwt(function(err, token) {
        if (err) {
          console.log(err);
        }
        return cb(null, token);
      });
    } else {
      return cb(null, token);
    }
  });
};
exports.getMovieByRedis = function(id, cb) {
  getMovieFromRedis(id, function(err, lists) {
    if (err) {
      console.log(err);
    }
    if (!lists) {
      getMovieFromMongo(id, function(err, lists) {
        if (err) {
          return cb(err, null);
        }
        return cb(null, lists);
      });
    } else {
      return cb(null, lists);
    }
  });
};
function getMovieFromRedis(id, cb) {
  client.get('movie:' + id, function(err, lists) {
    if (err) {
      console.log(err);
    }
    return cb(err, JSON.parse(lists));
  });
}
function getMovieFromMongo(id, cb) {
  Movie.findOne({ _id: id }).exec(function(err, movie) {
    if (err) {
      console.log(err);
    }
    if (!movie) {
      return cb('not found', null);
    }
    if (movie.status == 'waiting') {
      return cb('not found', null);
    }
    if (movie.totv) {
      return cb('not fount', null);
    }
    var query = {};
    var fenzu = [];
    var tags = movie.tags;
    if (tags.length > 3) {
      fenzu = group(tags, 3);
      query.$or = [];
      for (var i = 0; i < fenzu.length; i++) {
        // find({$or:[{tags: {$all: typeid}}, {types: {$all: typeid}}]})
        var allquery = {};
        allquery.tags = { $all: fenzu[i] };
        query.$or.push(allquery);
      }
    } else {
      query.tags = { $all: tags };
    }
    Movie.find(query)
      .limit(9)
      .exec(function(err, pushmovies) {
        if (err) {
          console.log(err);
        }
        var filterpush = _.filter(pushmovies, function(obj) {
          return obj._id != id.toString();
        });
        var lists = {
          movie: movie,
          pushmovies: filterpush
        };
        client.setex('movie:' + id, 3600, JSON.stringify(lists));
        return cb(err, lists);
      });
  });
}
function getMoviesFromJwt(cb) {
  Setting.find().exec(function(err, setting) {
    if (err) {
      cb(err, null);
    }
    var token = jwt.sign({ access: 'view' }, setting[0].antikey, {
      expiresIn: '100s'
    });
    client.setex('token', 99, token);
    cb(null, token);
  });
}
function getTokenFromRedis(cb) {
  client.get('token', function(err, token) {
    if (err) {
      console.log(err);
    }
    return cb(err, token);
  });
}
function group(nu, groupl, result) {
  var result = result ? result : [];
  var nuc = nu.slice(0);

  var item = nuc.shift();
  item = item.constructor === Array ? item : [item];

  function func(item, nuc) {
    var itemc;
    var nucc = nuc.slice(0);
    var margin = groupl - item.length;

    if (margin == 0) {
      result.push(item);
      return;
    }
    if (margin == 1) {
      for (var j in nuc) {
        itemc = item.slice(0);
        itemc.push(nuc[j]);
        result.push(itemc);
      }
    }
    if (margin > 1) {
      itemc = item.slice(0);
      itemc.push(nucc.shift());
      func(itemc, nucc);

      if (item.length + nucc.length >= groupl) {
        func(item, nucc);
      }
    }
  }
  func(item, nuc);

  if (nuc.length >= groupl) {
    return group(nuc, groupl, result);
  } else {
    return result;
  }
}
