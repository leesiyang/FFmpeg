const AlipaySdk = require('alipay-sdk').default;
const AlipayFormData = require('alipay-sdk/lib/form').default;
const Pay = require('../models/pay');
const Item = require('../models/item');
const User = require('../models/user');
const fs = require('fs');

async function alipayOne() {
  const pay = await Pay.findOne();
  const alipaySdk = new AlipaySdk({
    appId: pay.appid,
    privateKey: fs.readFileSync('./key/private-key.pem', 'ascii'),
    alipayPublicKey: fs.readFileSync('./key/public-key.pem', 'ascii')
  });
  return alipaySdk;
}
exports.pagepay = async function({
  notifyurl,
  returnurl,
  outtradeno,
  totalamount,
  subject,
  type
}) {
  const alipaySdk = await alipayOne();
  const formData = new AlipayFormData();
  let method = '';
  formData.setMethod('get');

  formData.addField('notifyUrl', notifyurl);
  formData.addField('returnUrl', returnurl);
  formData.addField('bizContent', {
    outTradeNo: outtradeno,
    productCode: 'FAST_INSTANT_TRADE_PAY',
    totalAmount: totalamount,
    subject: subject
  });
  if (type == 'wap') {
    method = 'alipay.trade.wap.pay';
  } else if (type == 'page') {
    method = 'alipay.trade.page.pay';
  }
  try {
    const result = await alipaySdk.exec(method, {}, { formData: formData });
    return result;
  } catch (err) {
    console.log(err);
  }
};

exports.check = async function(body) {
  const alipaySdk = await alipayOne();
  if (alipaySdk.checkNotifySign(body)) {
    console.log(body);
    const pay = await Pay.findOne();
    const item = await Item.findById(body.out_trade_no);
    if (
      item._id == body.out_trade_no &&
      item.amount == body.total_amount &&
      body.app_id == pay.appid
    ) {
      if (
        body.trade_status == 'TRADE_SUCCESS' ||
        body.trade_status == 'TRADE_FINISHED'
      ) {
        await Item.updateOne({ _id: item._id }, { $set: { status: 'done' } });
        await User.updateOne(
          { _id: item.uid },
          { $inc: { score: item.score } }
        );
        return 'success';
      } else {
        return 'fail';
      }
    } else {
      return 'fail';
    }
  } else {
    return 'fail';
  }
};
