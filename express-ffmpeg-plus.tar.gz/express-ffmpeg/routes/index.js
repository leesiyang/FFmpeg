var auth = require('../config/auth');
var Admincontroller = require('../controller/admin');
var Cmscontroller = require('../controller/cms');
var Portal = require('../models/portal');
var Setting = require('../models/setting');
var User = require('../models/user');
var config = require('../config/auth');
var multer = require('multer');
const { body } = require('express-validator/check');
var storage = multer.diskStorage({
  destination: function(req, file, cb) {
    cb(null, './movies');
  },
  filename: function(req, file, cb) {
    cb(null, file.originalname);
  }
});
var upload = multer({
  storage: storage,
  fileFilter: function(req, file, cb) {
    var fileFormat = file.originalname.toLowerCase().split('.');
    if (
      fileFormat[fileFormat.length - 1] !== 'mkv' &&
      fileFormat[fileFormat.length - 1] !== 'mp4' &&
      fileFormat[fileFormat.length - 1] !== 'avi' &&
      fileFormat[fileFormat.length - 1] !== 'rmvb' &&
      fileFormat[fileFormat.length - 1] !== 'rm' &&
      fileFormat[fileFormat.length - 1] !== 'flv' &&
      fileFormat[fileFormat.length - 1] !== 'mpeg' &&
      fileFormat[fileFormat.length - 1] !== 'vob' &&
      fileFormat[fileFormat.length - 1] !== 'srt' &&
      fileFormat[fileFormat.length - 1] !== 'ass'
    ) {
      cb(null, false);
    } else {
      cb(null, true);
    }
  }
});
var imagestorage = multer.diskStorage({
  destination: function(req, file, cb) {
    cb(null, './public/images');
  },
  filename: function(req, file, cb) {
    cb(null, file.originalname);
  }
});
var imagesupload = multer({
  storage: imagestorage
});
var articlestorage = multer.diskStorage({
  destination: function(req, file, cb) {
    cb(null, './public/uploads');
  },
  filename: function(req, file, cb) {
    var fileFormat = file.originalname.split('.');
    cb(
      null,
      file.fieldname +
        '-' +
        Date.now() +
        '.' +
        fileFormat[fileFormat.length - 1]
    );
  }
});
var articleupload = multer({
  storage: articlestorage,
  fileFilter: function(req, file, cb) {
    if (
      file.mimetype !== 'image/png' &&
      file.mimetype !== 'image/jpg' &&
      file.mimetype !== 'image/jpeg'
    ) {
      cb(null, false);
    } else {
      cb(null, true);
    }
  }
});
module.exports = function(app) {
  app.get(config.login, checkNotLogin, function(req, res, next) {
    res.render('hlsserver', {
      title: '云转码切片服务平台'
    });
  });
  app.post(config.login, checkNotLogin, function(req, res) {
    var user = req.body.user;
    var password = req.body.password;
    if (user == auth.user && password == auth.password) {
      req.session.user = user;
      res.redirect('/admin');
    } else {
      res.redirect('https://baidu.com');
    }
  });
  app.get('/hlslogout', checkLogin, function(req, res) {
    req.session.user = null;
    res.redirect(config.login);
  });
  function posttimeout(req, res, next) {
    req.setTimeout(10000, function() {
      res.statusCode = 500;
      return res.json({
        success: 0
      });
    });
    next();
  }
  app.get('/admin', checkLogin, Admincontroller.getadmin);
  app.get('/admin/upload', checkLogin, Admincontroller.getupload);
  app.get('/admin/movies', checkLogin, Admincontroller.getmovies);
  app.get('/admin/tv', checkLogin, Admincontroller.gettvs);
  app.get('/admin/comment', checkLogin, Admincontroller.getcomments);
  app.post('/api/shenhecomment', checkLogin, Admincontroller.apishenhecomment);
  app.delete('/api/deletecomment', checkLogin, Admincontroller.deletecomment);
  app.get('/api/getcomments', Cmscontroller.apigetcomments);
  app.get('/addtv', checkLogin, Admincontroller.addtv);
  app.post('/addtv', checkLogin, Admincontroller.postaddtv);
  app.get('/tv/:id/edit', checkLogin, Admincontroller.edittv);
  app.post('/tv/:id/edit', checkLogin, Admincontroller.postedittv);
  app.get('/tv/:id/addvideos', checkLogin, Admincontroller.addvideos);
  app.post('/tv/:id/addvideos', checkLogin, Admincontroller.postaddvideos);
  app.delete('/api/deletetv', checkLogin, Admincontroller.deletetv);
  app.post('/shenhe', checkLogin, Admincontroller.shenhe);
  // cms
  app.get('/cms', checkLogin, Cmscontroller.manager);
  app.get('/cms/images', checkLogin, Cmscontroller.cmsimages);
  app.get('/cms/articles', checkLogin, Cmscontroller.cmsarticles);
  app.get('/cms/postimages', checkLogin, Cmscontroller.postimages);
  app.post('/cms/postimages', checkLogin, Cmscontroller.dopostimages);
  app.get('/cms/postarticles', checkLogin, Cmscontroller.postarticles);
  app.post('/cms/postarticles', checkLogin, Cmscontroller.dopostarticles);
  app.post(
    '/imagesupload',
    checkLogin,
    imagesupload.single('image'),
    Cmscontroller.imagesupload
  );
  app.get('/image/:id', checkopen, Cmscontroller.getimage);
  app.get('/article/:id', checkopen, Cmscontroller.getarticle);
  app.post(
    '/upload/image',
    checkLogin,
    articleupload.single('editormd-image-file'),
    Cmscontroller.uploadimage
  );
  app.get('/discover', checkopen, Cmscontroller.discover);
  app.get('/imageslist', checkopen, Cmscontroller.getimages);
  app.get('/articles', checkopen, Cmscontroller.getarticles);
  app.get('/article/:id/edit', checkLogin, Cmscontroller.editarticle);
  app.post('/article/:id/edit', checkLogin, Cmscontroller.posteditarticle);
  app.get('/search', checkopen, Cmscontroller.getsearch);
  app.get('/tag/:tag', checkopen, Cmscontroller.getmoviesbytag);
  app.get('/tags', checkopen, Cmscontroller.getalltags);
  app.get('/taggroup/:id', checkopen, Cmscontroller.taggroup);
  app.get('/user/:name', checkopen, Cmscontroller.getuser);
  app.get('/user/:id/edit', checkopen, checkLevelLogin, Cmscontroller.getedituser);
  app.post('/user/:id/edit', checkopen, checkLevelLogin, Cmscontroller.postedituser);
  app.get(
    '/user/:id/uploads',
    checkopen,
    checkUserUploadOpen,
    checkLevelLogin,
    Cmscontroller.useruploads
  );
  app.get(
    '/userupload',
    checkopen,
    checkUserUploadOpen,
    checkLevelLogin,
    Cmscontroller.userupload
  );
  app.post(
    '/userupload',
    checkopen,
    checkUserUploadOpen,
    checkLevelLogin,
    upload.single('file'),
    Cmscontroller.postuserupload
  );
  app.get('/invite', checkopen, Cmscontroller.invite);
  app.get('/buyvip', checkopen, checkLevelLogin, Cmscontroller.buyvip);
  app.post('/buyvip', checkopen, checkLevelLogin, Cmscontroller.postbuyvip);
  app.get('/admin/pay', checkLogin, Cmscontroller.adminpay);
  app.post('/admin/pay', checkLogin, Cmscontroller.postadminpay);
  app.get('/admin/item', checkLogin, Cmscontroller.adminitem);
  app.post('/payback', checkopen, Cmscontroller.payback);
  app.get('/buyscore', checkopen,checkLevelLogin, Cmscontroller.buyscore);
  app.post('/buyscore', checkopen,checkLevelLogin, Cmscontroller.postbuyscore);
  app.get('/item/:id', checkopen,checkLevelLogin, Cmscontroller.getitem);
  app.post('/item/:id', checkopen,checkLevelLogin, Cmscontroller.postitem);
  // cms end
  // api
  app.post('/api/fabu', checkLogin, Admincontroller.fabu);
  app.post('/api/postcomment', checkLevelLogin, Cmscontroller.apipostcomment);
  app.post('/api/postlogin', checkApiOpen, Admincontroller.apipostlogin);
  app.post('/api/postreg', checkApiOpen, Admincontroller.apipostreg);
  app.get('/api/getuser', checkApiOpen, Admincontroller.apigetuser);
  app.get('/api/gettags', checkApiOpen, Admincontroller.apigettags);
  app.post('/api/connect', checkApiOpen, Admincontroller.apiconent);
  app.get('/api/setting', checkApiOpen, Admincontroller.apigetsetting);
  // app.post('/api/setting', checkApiOpen, Admincontroller.apipostsetting);
  // app.post('/api/tongbu', checkApiOpen, Admincontroller.tongbu);
  app.get('/api/m3u8/:id', checkApiOpen, Admincontroller.apim3u8);
  app.get('/api/getindex', checkApiOpen, Cmscontroller.apigetindex);
  app.get('/api/getmovies', checkApiOpen, Cmscontroller.apigetmovies);
  app.get('/api/getrandommovies', checkApiOpen, Cmscontroller.apigetrandommovies);
  app.get('/api/gethotmovies', checkApiOpen, Cmscontroller.apigethotmovies);
  app.get('/api/gettags', checkApiOpen, Cmscontroller.apigettags);
  app.get('/api/getthemovie', checkApiOpen, Cmscontroller.getthemovie);
  app.get('/api/getthetv', checkApiOpen, Cmscontroller.apitgetthetv);
  app.get('/api/getnewmovies', checkApiOpen, Cmscontroller.apigetnewmovies);
  app.get('/api/getmoviesbytag', checkApiOpen, Cmscontroller.apigetmoviesbytag);
  app.get('/api/getplay', checkApiOpen, Cmscontroller.apigetplay);
  app.get('/api/getmoviestab', checkApiOpen, Cmscontroller.apigetmoviestab);
  app.get('/api/getsearch', checkApiOpen, Cmscontroller.apigetsearchs);
  app.get('/api/search', checkLogin, Cmscontroller.apigetsearch);
  app.get('/api/getm3u8', checkApiOpen, Cmscontroller.apigetm3u8);
  app.get('/api/getmovie', Cmscontroller.apigetmovie);
  app.get('/api/getallm3u8', checkLogin, Admincontroller.getallm3u8);
  app.delete('/api/deletetag', checkLogin, Admincontroller.deletetag);
  app.get('/api/getbymd5', Admincontroller.getbymd5);
  // app.post('/api/transcode', checkApiOpen, Admincontroller.apitranscode);
  // app.delete('/api/deletemovie', checkApiOpen, Admincontroller.apideletemovie);
  app.post(
    '/api/checkfilemd5',
    checkLevelLogin,
    Admincontroller.apicheckfilemd5
  );
  app.post('/api/addtvposter', checkLogin, Admincontroller.addtvposter);
  app.post('/api/addmovieposter', checkLogin, Admincontroller.apiaddmovieposter);
  // app.post('/api/postmovie', checkApiOpen, Cmscontroller.apipostmovie);
  // api end
  app.post(
    '/upzimu',
    checkLogin,
    upload.single('zimu'),
    Admincontroller.postzimu
  );
  app.post(
    '/upload',
    checkLogin,
    posttimeout,
    upload.single('file'),
    Admincontroller.postupload
  );
  app.post('/transcode', checkLogin, Admincontroller.transcode);
  app.post('/listszhuanma', checkLogin, Admincontroller.listszhuanma);
  app.delete('/delete/movie', checkLogin, Admincontroller.delete);
  app.delete('/delete/category', checkLogin, Admincontroller.delcategory);
  app.delete('/delete/user', checkLogin, Admincontroller.deluser);
  app.delete('/delete/image', checkLogin, Cmscontroller.deleteimage);
  app.delete('/delete/article', checkLogin, Cmscontroller.deletearticle);
  app.delete('/deleteselected', checkLogin, Admincontroller.deleteselected);
  app.get('/share/:id', checkLevel, Admincontroller.getmovie);
  app.get('/', checkopen, Cmscontroller.index);
  app.get('/movies', Cmscontroller.getmovies);
  app.get('/tvs', checkopen, Cmscontroller.gettvs);
  app.get('/tv/:id', checkopen, Cmscontroller.gettv);
  app.get('/play/:id', checkopen, Cmscontroller.play);
  app.get('/playm3u8', Cmscontroller.playm3u8);
  app.get('/movie/:id', checkopen, Cmscontroller.getmovie);
  app.get('/movie/:id/edit', checkLogin, Admincontroller.editmovie);
  app.post('/movie/:id/edit', checkLogin, Admincontroller.postupdatemovie);
  app.get('/movie/:id/editname', checkLogin, Admincontroller.editmoviename);
  app.get('/hots', checkopen, Cmscontroller.hots);
  app.get('/random', checkopen, Cmscontroller.random);
  app.post(
    '/movie/:id/editname',
    checkLogin,
    Admincontroller.posteditmoviename
  );
  app.post(
    '/movies/updatecategory',
    checkLogin,
    Admincontroller.updatecategory
  );
  app.get('/categories', checkopen, Cmscontroller.getcategories);
  app.get('/category/:category', checkopen, Cmscontroller.getcategory);
  app.get('/admin/setting', checkLogin, Admincontroller.setting);
  app.post('/admin/setting/basic', checkLogin, Admincontroller.postsetting);
  app.post('/admin/setting/fenfa', checkLogin, Admincontroller.postfenfa);
  app.post('/ruku', checkLogin, Admincontroller.ruku);
  app.post('/pushtoindex', checkLogin, Admincontroller.pushtoindex);
  app.get('/playmagnet', Admincontroller.playmagnet);
  app.post('/addcategory', checkLogin, Admincontroller.addcategory);
  app.get('/admin/categories', checkLogin, Admincontroller.getCategories);
  app.get('/category/:id/edit', checkLogin, Admincontroller.editcategory);
  app.post('/category/:id/edit', checkLogin, Admincontroller.posteditcategory);
  app.get('/admin/portal', checkLogin, Admincontroller.portal);
  app.post('/admin/portal', checkLogin, Admincontroller.postportal);
  app.get('/admin/bofangqi', checkLogin, Admincontroller.bofangqi);
  app.post('/admin/bofangqi', checkLogin, Admincontroller.postbofangqi);
  app.get('/admin/tongji', checkLogin, Admincontroller.tongji);
  app.get('/admin/buyvip', checkLogin, Admincontroller.adminvip);
  app.get('/admin/addvipbuy', checkLogin, Admincontroller.addvipbuy);
  app.post('/admin/addvipbuy', checkLogin, Admincontroller.postaddvipbuy);
  app.delete('/api/deletevipbuy', checkLogin, Admincontroller.deletevipbuy);
  app.get('/api/getjiage', Cmscontroller.getjiage);
  app.get('/api/getmianzhi', Cmscontroller.getmianzhi);
  app.post('/selectedcategory', checkLogin, Admincontroller.selectedcategory);
  app.post('/admin/adddingzhi', checkLogin, Admincontroller.adddingzhi);
  app.post('/selectedcuthead', checkLogin, Admincontroller.cuthead);
  app.get(
    '/login',
    checkUsersystemOpen,
    checkLevelNotLogin,
    Admincontroller.login
  );
  app.post(
    '/login',
    checkUsersystemOpen,
    checkLevelNotLogin,
    [
      body('email')
        .isEmail()
        .normalizeEmail(),
      body('password')
        .not()
        .isEmpty()
        .trim()
        .escape()
    ],
    Admincontroller.postlogin
  );
  app.get(
    '/logout',
    checkUsersystemOpen,
    checkLevelLogin,
    Admincontroller.logout
  );
  app.get(
    '/register',
    checkUsersystemOpen,
    checkLevelNotLogin,
    Admincontroller.reg
  );
  app.post(
    '/register',
    checkUsersystemOpen,
    checkLevelNotLogin,
    [
      body('username')
        .trim()
        .isLength({ min: 6, max: 16 })
        .escape(),
      body('email')
        .isEmail()
        .normalizeEmail(),
      body('password')
        .trim()
        .isLength({ min: 6, max: 16 })
        .escape()
    ],
    Admincontroller.postreg
  );
  app.get('/admin/shuiyin', checkLogin, Admincontroller.adminshuiyin);
  app.get('/admin/addwatermark', checkLogin, Admincontroller.addwatermark);
  app.post('/admin/addwatermark', checkLogin, Admincontroller.postaddwatermark);
  app.delete('/delete/watermark', checkLogin, Admincontroller.deletewatermark);
  app.get('/admin/users', checkLogin, Admincontroller.adminusers);
  app.get('/admin/user/:id/edit', checkLogin, Admincontroller.edituser);
  app.post('/admin/user/:id/edit', checkLogin, Admincontroller.postedituser);
  app.post('/admin/gencard', checkLogin, Admincontroller.gencard);
  app.get('/admin/cards', checkLogin, Admincontroller.cards);
  app.get('/admin/tags', checkLogin, Admincontroller.gettags);
  app.get('/admin/addtaggroup', checkLogin, Admincontroller.addtaggroup);
  app.post('/admin/addtaggroup', checkLogin, Admincontroller.posttaggroup);
  app.post('/admin/tagstogroup', checkLogin, Admincontroller.tagstogroup);
  app.get('/admin/taggroup/:id/edit', checkLogin, Admincontroller.editgroup);
  app.get('/admin/groups', checkLogin, Admincontroller.getgroups);
  app.get('/admin/addusergroup', checkLogin, Admincontroller.addusergroup);
  app.get(
    '/admin/addvipusergroup',
    checkLogin,
    Admincontroller.addvipusergroup
  );
  app.post(
    '/admin/addvipusergroup',
    checkLogin,
    Admincontroller.postaddvipgroup
  );
  app.post('/admin/addusergroup', checkLogin, Admincontroller.postaddgroup);
  app.get('/admin/editgroup', checkLogin, Admincontroller.editusergroup);
  app.post('/admin/editgroup', checkLogin, Admincontroller.posteditusergroup);
  app.get('/admin/editvipgroup', checkLogin, Admincontroller.editvipgroup);
  app.post('/admin/editvipgroup', checkLogin, Admincontroller.posteditvipgroup);
  app.post(
    '/admin/taggroup/:id/edit',
    checkLogin,
    Admincontroller.posteditgroup
  );
  app.get(
    '/addcard',
    checkUsersystemOpen,
    checkLevelLogin,
    Admincontroller.addcard
  );
  app.post(
    '/addcard',
    checkUsersystemOpen,
    checkLevelLogin,
    [
      body('card')
        .trim()
        .matches(/^[\S]{20}$/)
        .withMessage('必须20个非空字符')
        .escape()
    ],
    Admincontroller.postcard
  );
  var storage1 = multer.diskStorage({
    destination: function(req, file, cb) {
      cb(null, './public/mark');
    },
    filename: function(req, file, cb) {
      cb(null, file.originalname);
    }
  });
  var upload1 = multer({
    storage: storage1
  });
  app.post(
    '/upwm',
    checkLogin,
    upload1.single('img'),
    Admincontroller.uploadwatermark
  );
  app.post(
    '/uploadwatermark',
    checkLogin,
    upload1.single('img'),
    Admincontroller.uploadwatermark
  );
  // 上传类api
  app.all(
    '/api/uploadwatermark',
    checkApiOpen,
    upload1.single('img'),
    Admincontroller.apiuploadwatermark
  );
  app.all(
    '/api/upload',
    checkUploadkey,
    upload.single('file'),
    Admincontroller.apiupload
  );
  // 结束
  var storage2 = multer.diskStorage({
    destination: function(req, file, cb) {
      cb(null, './public/videos/');
    },
    filename: function(req, file, cb) {
      cb(null, file.originalname);
    }
  });
  var upload2 = multer({
    storage: storage2
  });
  app.post(
    '/upvtt',
    checkLogin,
    upload2.single('vtt'),
    Admincontroller.uploadvtt
  );
  app.post(
    '/upposter',
    checkLogin,
    upload2.single('image'),
    Admincontroller.uploadposter
  );
  app.post(
    '/uptvposter',
    checkLogin,
    upload2.single('image'),
    Admincontroller.uploadtvposter
  );
  function checkLogin(req, res, next) {
    if (!req.session.user) {
      return res.status(404).send(config.loginmsg);
    }
    next();
  }
  app.get('/admin/card.txt', checkLogin, Admincontroller.getcardtxt);
  function checkNotLogin(req, res, next) {
    if (req.session.user) {
      return res.redirect('/admin');
    }
    next();
  }
  function checkLevelLogin(req, res, next) {
    if (!req.session.leveluser) {
      return res.redirect('/login');
    }
    next();
  }

  function checkLevelNotLogin(req, res, next) {
    if (req.session.leveluser) {
      return res.redirect('/');
    }
    next();
  }
  function checkopen(req, res, next) {
    Portal.find().exec(function(err, portals) {
      if (err) {
        console.log(err);
      }
      if (portals.length > 0) {
        if (portals[0].kaiguan == 'on') {
          req.portal = portals[0];
          return next();
        } else {
          return res.status(404).send('对不起，cms未开启');
        }
      } else {
        return res.status(404).send('对不起，cms未开启');
      }
    });
  }
  function checkUsersystemOpen(req, res, next) {
    Portal.find().exec(function(err, portals) {
      if (err) {
        console.log(err);
      }
      if (portals[0].usersystem != 'on') {
        return res.status(404).send('会员系统未开启');
      } else {
        req.portal = portals[0];
        next();
      }
    });
  }
  function checkUserUploadOpen(req, res, next) {
    if (req.portal.userupload != 'on') {
      return res.status(404).send('未开启会员上传');
    } else {
      next();
    }
  }
  function checkLevel(req, res, next) {
    req.level = 2;
    if (req.session.leveluser) {
      User.findOne({ username: req.session.leveluser }).exec(function(
        err,
        user
      ) {
        if (err) {
          console.log(err);
        }
        if (user.level == 2) {
          req.level = 2;
          next();
        } else {
          req.level = 1;
          next();
        }
      });
    } else {
      Portal.find().exec(function(err, portals) {
        if (err) {
          console.log(err);
        }
        if (portals[0].usersystem == 'on') {
          req.level = 0;
          next();
        } else {
          next();
        }
      });
    }
  }
  function checkApiOpen(req, res, next) {
    Setting.find().exec(function(err, setting) {
      if (err) {
        console.log(err);
      }
      var antiurlarr = setting[0].antiurl;
      if (antiurlarr.indexOf(req.headers.origin) != -1) {
        res.header('Access-Control-Allow-Origin', req.headers.origin);
        res.header(
          'Access-Control-Allow-Methods',
          'POST, GET, OPTIONS, DELETE'
        );
        res.header('Access-Control-Allow-Headers', 'Content-Type');
        res.header(
          'Access-Control-Allow-Headers',
          'X-Requested-With, token, Accept'
        );
      }
      var api = setting[0].api;
      if (api != 'on') {
        return res.status(404).send('API未开启。');
      }
      const apikey = req.body.apikey || req.query.apikey || req.headers.token;
      if (apikey != setting[0].apikey) {
        return res.json({ done: 0 });
      }
      req.apikey = apikey;
      next();
    });
  }
  function checkUploadkey(req, res, next) {
    Setting.find().exec(function(err, setting) {
      if (err) {
        console.log(err);
      }
      var antiurlarr = setting[0].antiurl;
      if (antiurlarr.indexOf(req.headers.origin) != -1) {
        res.header('Access-Control-Allow-Origin', req.headers.origin);
        res.header('Access-Control-Allow-Methods', 'POST, GET, OPTIONS');
        res.header('Access-Control-Allow-Headers', 'Content-Type');
        res.header(
          'Access-Control-Allow-Headers',
          'X-Requested-With, token, Accept'
        );
      }
      var api = setting[0].api;
      if (api != 'on') {
        return res.status(404).send('API未开启');
      }
      const uploadkey = req.headers.token || req.body.uploadkey;
      if (uploadkey != setting[0].uploadkey) {
        return res.json({ done: 0, message: '对不起，您没权限' });
      }
      next();
    });
  }
};
