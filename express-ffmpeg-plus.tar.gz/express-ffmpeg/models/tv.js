var mongoose = require("mongoose")
var TvSchema = require("../schemas/tv")
var Tv = mongoose.model("Tv", TvSchema)

module.exports = Tv
