var mongoose = require("mongoose")
var TaggroupSchema = require("../schemas/taggroup")
var Taggroup = mongoose.model("Taggroup", TaggroupSchema)

module.exports = Taggroup
