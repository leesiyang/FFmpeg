var mongoose = require("mongoose")
var VipuserSchema = require("../schemas/vipuser")
var Vipuser = mongoose.model("Vipuser", VipuserSchema)

module.exports = Vipuser
