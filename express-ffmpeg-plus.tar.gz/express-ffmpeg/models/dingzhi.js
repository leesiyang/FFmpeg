var mongoose = require('mongoose');
var DingzhiSchema = require('../schemas/dingzhi');
var Dingzhi = mongoose.model('Dingzhi', DingzhiSchema);

module.exports = Dingzhi;
