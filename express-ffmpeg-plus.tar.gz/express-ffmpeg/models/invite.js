var mongoose = require("mongoose")
var InviteSchema = require("../schemas/invite")
var Invite = mongoose.model("Invite", InviteSchema)

module.exports = Invite
