var mongoose = require('mongoose');
var UseruploadSchema = require('../schemas/userupload');
var Userupload = mongoose.model('Userupload', UseruploadSchema);

module.exports = Userupload;
