var mongoose = require('mongoose');
var WatermarkSchema = require('../schemas/watermark');
var Watermark = mongoose.model('Watermark', WatermarkSchema);

module.exports = Watermark;
