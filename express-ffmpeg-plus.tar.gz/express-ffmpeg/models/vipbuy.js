var mongoose = require("mongoose")
var VipbuySchema = require("../schemas/vipbuy")
var Vipbuy = mongoose.model("Vipbuy", VipbuySchema)

module.exports = Vipbuy
