var Movie = require('../models/movie');
var Category = require('../models/category');
var Portal = require('../models/portal');
var Image = require('../models/image');
var Article = require('../models/article');
var Setting = require('../models/setting');
var Push = require('../models/push');
var Tag = require('../models/tag');
var Taggroup = require('../models/taggroup');
var User = require('../models/user');
var Invite = require('../models/invite');
var Group = require('../models/group');
var Tv = require('../models/tv');
var Vipuser = require('../models/vipuser');
var Vipbuy = require('../models/vipbuy');
var Card = require('../models/card');
const Comment = require('../models/comment');
const Pay = require('../models/pay');
const Item = require('../models/item');
var Userupload = require('../models/userupload');
var cache = require('../helper/rediscache');
var moment = require('moment');
var fs = require('fs');
var sharp = require('sharp');
var async = require('async');
var _ = require('underscore');
const alipay = require('../helper/alipay');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
exports.index = async function(req, res) {
  cache.getIndexByRedis(function(err, results) {
    if(err) {
      console.log(err);
    }
    res.render(req.portal.theme + '/index', {
      portal: req.portal,
      pushmovies: results.pushmovies,
      hotmovies: results.hotmovies,
      hottvs: results.hottvs,
      newmovies: results.newmovies,
      newtvs: results.newtvs,
      news: results.news,
      user: req.session.leveluser
    });
  });
};
exports.gettvs = async function(req, res) {
  var page = req.query.page > 0 ? req.query.page : 1;
  var perPage = 12;
  const tags = await Tag.find()
    .sort('-counts')
    .limit(15);
  const tvs = await Tv.find()
    .sort('-createAt')
    .limit(perPage)
    .skip(perPage * (page - 1));
  const count = await Tv.countDocuments();
  let lianzaitvs = [];
  if (page == 1) {
    lianzaitvs = await Tv.find({ status: 'lianzai' });
  }
  res.render(req.portal.theme + '/tvs', {
    title: '动漫大全,动画番剧大全',
    tags: tags,
    tvs: tvs,
    page: page,
    lianzaitvs,
    user: req.session.leveluser,
    pages: Math.ceil(count / perPage),
    portal: req.portal
  });
};
exports.gettv = async (req, res) => {
  const id = req.params.id;
  const tv = await Tv.findById(id);
  const counts = await Tv.find();
  let skip = Math.floor(Math.random() * (counts - 8));
  if (skip < 0) {
    skip = 0;
  }
  const pushtvs = await Tv.find()
    .limit(8)
    .skip(skip);
  if (!tv) {
    return res.status(404).send('页面不存在');
  } else {
    res.render(req.portal.theme + '/tv', {
      title: tv.title,
      portal: req.portal,
      tv: tv,
      pushtvs: pushtvs,
      user: req.session.leveluser
    });
  }
};
exports.play = async (req, res) => {
  const id = req.params.id;
  const movie = await Movie.findById(id);
  if (!movie.totv) {
    res.status(404);
    return res.render(req.portal.theme + '/404', {
      message: '对不起此页面不存在。',
      portal: req.portal
    });
  }
  const tv = await Tv.findById(movie.totv);
  const counts = await Tv.find();
  await Tv.updateOne({ _id: movie.totv }, { $inc: { count: 1 } });
  let tags = [];
  tags = tags.concat(tv.director, tv.stars, tv.country, tv.tags, tv.writer);
  tags = _.uniq(tags);
  let skip = Math.floor(Math.random() * (counts - 8));
  if (skip < 0) {
    skip = 0;
  }
  const pushtvs = await Tv.find()
    .limit(6)
    .skip(skip);
  const comments = await Comment.find({status: 'published', movieid: id}).limit(20).sort('-createAt').populate('uid');
  const commentcounts = await Comment.countDocuments({status: 'published', movieid: id});
  res.render(req.portal.theme + '/play', {
    title: movie.originalname,
    portal: req.portal,
    user: req.session.leveluser,
    movie,
    tv,
    tags,
    pushtvs,
    comments,
    commentcounts
  });
};
exports.getmovies = function(req, res) {
  var page = req.query.page > 0 ? req.query.page : 1;
  var perPage = 12;
  Portal.find().exec(function(err, portals) {
    if (err) {
      console.log(err);
    }
    if (portals[0].kaiguan == 'on') {
      Tag.find()
        .sort('-counts')
        .limit(10)
        .exec(function(err, tags) {
          if (err) {
            console.log(err);
          }
          Movie.find({ status: 'finished' })
            .sort('-createAt')
            .limit(perPage)
            .skip(perPage * (page - 1))
            .exec(function(err, movies) {
              if (err) {
                console.log(err);
              }
              Movie.find({ status: 'finished' }).count(function(err, count) {
                var length = movies.length;
                var jiange = parseInt(perPage / 3);
                var results = [];
                for (var i = 0; i < length; i = i + jiange) {
                  results.push(movies.slice(i, i + jiange));
                }
                res.render(portals[0].theme + '/movies', {
                  tags: tags,
                  movies: movies,
                  page: page,
                  user: req.session.leveluser,
                  pages: Math.ceil(count / perPage),
                  portal: portals[0]
                });
              });
            });
        });
    } else {
      res.status(404).send('对不起，页面不存在');
    }
  });
};

exports.getmovie = function(req, res) {
  var id = req.params.id;
  cache.getMovieByRedis(id, async function(err, lists) {
    if (err) {
      res.status(404);
      return res.render(req.portal.theme + '/404', {
        message: '对不起此页面不存在，善用搜索。',
        portal: req.portal
      });
    }
    await Movie.updateOne({ _id: id }, { $inc: { count: 1 } });
    const comments = await Comment.find({status: 'published', movieid: id}).limit(20).sort('-createAt').populate('uid');
    const commentcounts = await Comment.countDocuments({status: 'published', movieid: id});
    res.render(req.portal.theme + '/cmsmovie', {
      portal: req.portal,
      movie: lists.movie,
      pushmovies: lists.pushmovies,
      user: req.session.leveluser,
      comments,
      commentcounts
    });
  });
};
exports.apigetcomments = async (req, res) => {
  const { id, page } = req.query;
  const comments = await Comment.find({movieid: id, status: 'published'}).limit(20).skip((page-1)*20).sort('-createAt').populate('uid');
  if(comments.length) {
    if(comments.length==20) {
      res.json({success: 1, comments, finished: false});
    } else {
      res.json({success:1, comments, finished: true});
    }
  } else {
    res.json({success: 0});
  }
}
exports.getcategories = async function(req, res) {
  res.render(req.portal.theme + '/categories', {
    title: '分类',
    user: req.session.leveluser,
    portal: req.portal
  })
};
exports.getcategory = async function(req, res) {
  var category = req.params.category;
  var page = req.query.page > 0 ? req.query.page : 1;
  var perPage = 12;
  const movies = await Movie.find({status: 'finished', category: category})
      .sort('-createAt')
      .limit(perPage)
      .skip(perPage * (page - 1))
  const count = await Movie.countDocuments({status: 'finished', category: category});
  res.render(req.portal.theme + '/category', {
    title: category,
    movies: movies,
    page: page,
    user: req.session.leveluser,
    pages: Math.ceil(count / perPage),
    portal: req.portal
  })
};

exports.manager = function(req, res) {
  res.render('cmsmanager', {
    title: 'cms管理系统页面'
  });
};

exports.cmsimages = function(req, res) {
  var page = req.query.page > 0 ? req.query.page : 1;
  var perPage = 15;
  Image.find()
    .sort('-createAt')
    .limit(perPage)
    .skip(perPage * (page - 1))
    .exec(function(err, images) {
      if (err) {
        console.log(err);
      }
      Image.find().count(function(err, count) {
        if (err) {
          console.log(err);
        }
        res.render('cmsimages', {
          title: 'cms图集管理',
          page: page,
          pages: Math.ceil(count / perPage),
          images: images
        });
      });
    });
};
exports.cmsarticles = function(req, res) {
  var page = req.query.page > 0 ? req.query.page : 1;
  var perPage = 15;
  Article.find()
    .sort('-createAt')
    .limit(perPage)
    .skip(perPage * (page - 1))
    .exec(function(err, articles) {
      if (err) {
        console.log(err);
      }
      Article.find().count(function(err, count) {
        if (err) {
          console.log(err);
        }
        res.render('cmsarticles', {
          title: 'cms图集管理',
          page: page,
          pages: Math.ceil(count / perPage),
          articles: articles
        });
      });
    });
};
exports.postarticles = function(req, res) {
  res.render('cmspostarticles', {
    title: '发布文章'
  });
};
exports.dopostarticles = function(req, res) {
  var title = req.body.title;
  var content = req.body['editormd-html-code'][1];
  var contentmd = req.body['editormd-html-code'][0];
  var articleobj = {
    title: title,
    content: content,
    contentmd: contentmd
  };
  var newaritcle = new Article(articleobj);
  newaritcle.save(function(err) {
    if (err) {
      console.log(err);
    }
    res.redirect('/cms/articles');
  });
};
exports.uploadimage = function(req, res) {
  var url = '/uploads/' + req.file.filename;
  res.json({
    success: 1,
    message: '上传图片成功！',
    url: url
  });
};
exports.postimages = function(req, res) {
  res.render('cmspostimages', {
    title: '发布图集'
  });
};
exports.dopostimages = function(req, res) {
  var title = req.body.title;
  var images = [];
  images = images.concat(req.body.images);
  images = images.sort();
  var poster = req.body.poster;
  if (!poster) {
    poster = images[0];
  }
  var imageobj = {
    title: title
  };
  var image = new Image(imageobj);
  image.save(function(err, image) {
    if (err) {
      console.log(err);
    }
    var path = './public/images/' + image._id;
    var filepath = '/images/' + image._id;
    fs.exists(path, function(exists) {
      if (!exists) {
        fs.mkdir(path, function(err) {
          if (err) {
            console.log(err);
          }
          var newimages = [];
          for (let index = 0; index < images.length; index++) {
            var imagearr = images[index].split('.');
            var houzhui = imagearr[imagearr.length - 1];
            var des = path + '/' + index + '.' + houzhui;
            var src = filepath + '/' + index + '.' + houzhui;
            fs.renameSync(images[index], des);
            if (images[index] == poster) {
              sharp(des)
                .resize(400, 300)
                .toFile(path + '/poster.jpg', function(err) {
                  if (err) {
                    console.log(err);
                  }
                });
            }
            newimages.push(src);
          }
          image.images = newimages;
          image.poster = filepath + '/poster.jpg';
          image.save(function(err) {
            if (err) {
              console.log(err);
            }
            res.redirect('/cms/images');
          });
        });
      }
    });
  });
};
exports.imagesupload = function(req, res) {
  res.json({
    code: 0,
    image: '/images/' + req.file.originalname,
    imagepath: './public/images/' + req.file.originalname
  });
};
exports.getimages = function(req, res) {
  var page = req.query.page > 0 ? req.query.page : 1;
  var perPage = 12;
  Image.find()
    .sort('-createAt')
    .limit(perPage)
    .skip(perPage * (page - 1))
    .exec(function(err, images) {
      if (err) {
        console.log(err);
      }
      Image.find().count(function(err, count) {
        if (err) {
          console.log(err);
        }
        res.render(req.portal.theme + '/images', {
          title: req.portal.imagestitle,
          images: images,
          page: page,
          user: req.session.leveluser,
          pages: Math.ceil(count / perPage),
          portal: req.portal
        });
      });
    });
};
exports.getarticles = function(req, res) {
  var page = req.query.page > 0 ? req.query.page : 1;
  var perPage = 12;
  Article.find()
    .sort('-createAt')
    .limit(perPage)
    .skip(perPage * (page - 1))
    .exec(function(err, articles) {
      if (err) {
        console.log(err);
      }
      Article.find().count(function(err, count) {
        if (err) {
          console.log(err);
        }
        res.render(req.portal.theme + '/articles', {
          title: req.portal.articlestitle,
          articles: articles,
          page: page,
          user: req.session.leveluser,
          pages: Math.ceil(count / perPage),
          portal: req.portal
        });
      });
    });
};
exports.getimage = function(req, res) {
  // var page = req.query.page > 0 ? req.query.page : 1;
  var id = req.params.id;
  Image.findOne({ _id: id }).exec(function(err, image) {
    if (err) {
      console.log(err);
    }
    if (!image) {
      return res.status(404).send('页面已经不存在');
    }
    return res.render(req.portal.theme + '/image', {
      title: image.title,
      images: image.images,
      user: req.session.leveluser,
      portal: req.portal
    })
    // var length = image.images.length;
    // if (parseInt(page) > length) {
    //   page = length;
    // }
    // Image.find()
    //   .sort('-createAt')
    //   .limit(4)
    //   .exec(function(err, newimages) {
    //     if (err) {
    //       console.log(err);
    //     }
    //     res.render(req.portal.theme + '/image', {
    //       title: image.title,
    //       page: page,
    //       image: image.images[page - 1],
    //       length: length,
    //       user: req.session.leveluser,
    //       newimages: newimages,
    //       portal: req.portal
    //     });
    //   });
  });
};
exports.discover = async (req, res) => {
  const tags = await Tag.find().limit(150).sort('-counts');
  const taggroups = await Taggroup.find();
  res.render(req.portal.theme + '/discover', {
    title: '发现更多精彩',
    portal: req.portal,
    user: req.session.leveluser,
    tags,
    taggroups
  })
}
exports.getarticle = function(req, res) {
  var id = req.params.id;
  Article.findOne({ _id: id }).exec(function(err, article) {
    if (err) {
      console.log(err);
    }
    res.render(req.portal.theme + '/article', {
      title: article.title,
      article: article,
      user: req.session.leveluser,
      data: moment(article.createAt).format('YYYY年MM月DD日, HH:mm:ss'),
      portal: req.portal
    });
  });
};
exports.deleteimage = function(req, res) {
  var id = req.query.id;
  Image.findOne({ _id: id }).exec(function(err, image) {
    if (err) {
      console.log(err);
    }
    image.remove(function(err) {
      if (err) {
        console.log(err);
      }
      deleteall('./public/images/' + image._id);
      res.json({ success: 1 });
    });
  });
};
exports.deletearticle = function(req, res) {
  var id = req.query.id;
  Article.findOne({ _id: id }).exec(function(err, article) {
    if (err) {
      console.log(err);
    }
    article.remove(function(err) {
      if (err) {
        console.log(err);
      }
      res.json({ success: 1 });
    });
  });
};
exports.editarticle = function(req, res) {
  var id = req.params.id;
  Article.findOne({ _id: id }).exec(function(err, article) {
    if (err) {
      console.log(err);
    }
    res.render('editarticle', {
      title: '编辑文章',
      article: article
    });
  });
};
exports.posteditarticle = function(req, res) {
  var id = req.params.id;
  var title = req.body.title;
  var content = req.body['editormd-html-code'][1];
  var contentmd = req.body['editormd-html-code'][0];
  Article.findOne({ _id: id }).exec(function(err, article) {
    if (err) {
      console.log(err);
    }
    article.title = title;
    article.content = content;
    article.contentmd = contentmd;
    article.save(function(err) {
      if (err) {
        console.log(err);
      }
      res.redirect('/cms/articles');
    });
  });
};
exports.getsearch = async function(req, res) {
  var q = req.query.q;
  var perPage = 50;
  const tvfind = {'episodes.0': {$exists: 1}};
  const movies = await Movie.find({
    originalname: { $regex: q, $options: 'i' }
  })
    .where({status: 'finished'})
    .sort('-createAt')
    .limit(perPage);
  const tvs = await Tv.find({ title: { $regex: q, $options: 'i' } })
    .where(tvfind)
    .sort('-createAt')
    .limit(perPage);
  var lists = [];
  lists = lists.concat(movies, tvs);
  lists = _.shuffle(lists);
  res.render(req.portal.theme + '/search', {
    portal: req.portal,
    lists: lists,
    user: req.session.leveluser,
    query: q
  });
};
exports.apigetsearchs = async (req, res) => {
  const q = req.query.q;
  const perPage = 30;
  const tvfind = {'episodes.0': {$exists: 1}};
  const movies = await Movie.find({
    originalname: { $regex: q, $options: 'i' },
    status: 'finished'
  })
    .sort('-createAt')
    .limit(perPage);
  const tvs = await Tv.find({ title: { $regex: q, $options: 'i' } })
    .where(tvfind)
    .sort('-createAt')
    .limit(perPage);
  var lists = [];
  lists = lists.concat(movies, tvs);
  res.json({success: 1, movies: lists});
}
exports.apigetmoviesbytag = async (req, res) => {
  const tvfind = {'episodes.0': {$exists: 1}};
  const page = req.query.page > 0 ? req.query.page : 1;
  const tag = req.query.tag ? req.query.tag : '精选';
  let find = {};
  if(tag != '精选') {
    find = {$or: [
      { director: tag },
      { stars: tag },
      { writer: tag },
      { country: tag },
      { tags: tag }
    ]};
  }
  let perPage = 20;
  const movies = await Movie.find(find)
    .where({status: 'finished'})
    .sort('-createAt')
    .limit(perPage)
    .skip(perPage * (page - 1))
  const tvs = await Tv.find(tvfind)
    .where(find)
    .sort('-createAt')
    .limit(perPage)
    .skip(perPage * (page - 1))
  var lists = [];
  lists = lists.concat(movies, tvs);
  lists = _.sortBy(lists, function(list) {
    return -list.createAt;
  });
  res.json({success: 1, movies: lists});
}
exports.apigetindex = function(req, res) {
  var perPage = req.query.counts > 0 ? req.query.counts * 1 : 20;
  async.parallel(
    {
      movies: function(callback) {
        Movie.find({ status: 'finished' })
          .sort('-createAt')
          .limit(perPage)
          .exec(function(err, movies) {
            if (err) {
              callback(err, null);
            }
            callback(null, movies);
          });
      },
      pushmovies: function(callback) {
        Push.find()
          .sort('-createAt')
          .limit(6)
          .populate('movieid')
          .exec(function(err, pushmovies) {
            if (err) {
              callback(err, null);
            }
            callback(null, pushmovies);
          });
      }
    },
    function(err, results) {
      if (err) {
        return res.json({
          error: err
        });
      }
      res.json({
        movies: results.movies,
        pushmovies: results.pushmovies
      });
    }
  );
};
exports.apigettags = async (req, res) => {
  const perPage = 150;
  const tags = await Tag.find().sort('-counts').limit(perPage);
  return res.json({success:1, tags});
}
exports.apigetrandommovies = async(req, res) => {
  const tvfind = {'episodes.0': {$exists: 1}};
  const moviescount = await Movie.countDocuments().where({status: 'finished'});
  const tvcount = await Tv.countDocuments(tvfind);
  let movieskip = Math.floor(Math.random() * (moviescount - 50));
  let tvskip = Math.floor(Math.random * (tvcount -50 ));
  if (movieskip < 0) {
    movieskip = 0;
  }
  if (tvskip < 0) {
    tvskip = 0;
  }
  const movies = await Movie.find({status: 'finished'})
      .limit(50)
      .skip(movieskip)
  const tvs = await Tv.find(tvfind).limit(50).skip(tvskip);
  var lists = [];
  lists = lists.concat(movies, tvs);
  lists = _.shuffle(lists);
  const randommovies = lists;
  return res.json({success:1, randommovies});
}
exports.apigethotmovies = async(req, res) => {
  const perPage = 100;
  const now = new Date();
  const month = new Date(now.getTime() - 30 * 24 * 3600 * 1000);
  const year = new Date(now.getTime() - 365 * 24 * 3600 * 1000);
  const week = new Date(now.getTime() - 7 * 24 * 3600 * 1000);
  const tvfind = {'episodes.0': {$exists: 1}};
  const monthhotmovies = await Movie.find({status: 'finished'})
     .where('createAt').gt(month)
     .sort('-count')
     .limit(perPage)
  const monthhottvs = await Tv.find(tvfind)
     .where('createAt').gt(month)
     .sort('-count')
     .limit(perPage);
  const yearhotmovies = await Movie.find({status: 'finished'})
     .where('createAt').gt(year)
     .sort('-count')
     .limit(perPage)
  const yearhottvs = await Tv.find(tvfind)
     .where('createAt').gt(year)
     .sort('-count')
     .limit(perPage);
  const weekhotmovies = await Movie.find({status: 'finished'})
     .where('createAt').gt(week)
     .sort('-count')
     .limit(perPage)
  const weekhottvs = await Tv.find(tvfind)
     .where('createAt').gt(week)
     .sort('-count')
     .limit(perPage);
  let monthmovies = [];
  monthmovies = monthmovies.concat(monthhotmovies, monthhottvs);
  monthmovies = _.sortBy(monthmovies, function(list) {
    return -list.count;
  });
  let yearmovies = [];
  yearmovies = yearmovies.concat(yearhotmovies, yearhottvs);
  yearmovies = _.sortBy(yearmovies, function(list) {
    return -list.count;
  });
  let weekmovies = [];
  weekmovies = weekmovies.concat(weekhotmovies, weekhottvs);
  weekmovies = _.sortBy(weekmovies, function(list) {
    return -list.count;
  });
  return res.json({success:1 , monthmovies, weekmovies, yearmovies});
}
exports.apigetnewmovies = async (req, res) => {
  const page = req.query.page > 0 ? req.query.page : 1;
  const tag = req.query.tag ? req.query.tag : '精选';
  let find = {};
  if(tag != '精选') {
    find = {$or: [
      { director: tag },
      { stars: tag },
      { writer: tag },
      { country: tag },
      { tags: tag }
    ]};
  }
  let perPage = 20;
  const tvfind = {'episodes.0': {$exists: 1}};
  const movies = await Movie.find({ status: 'finished'})
    .where(find)
    .sort('-createAt')
    .limit(perPage)
    .skip(perPage * (page - 1));
  const tvs = await Tv.find(find)
    .where(tvfind)
    .sort('-createAt')
    .limit(perPage)
    .skip(perPage * (page - 1));
  var lists = [];
  lists = lists.concat(movies, tvs);
  lists = _.sortBy(lists, function(list) {
    return -list.createAt;
  });
  const newmovies = lists;
  res.json({success: 1, newmovies});
}
exports.apigetmovies = function(req, res) {
  const tag = req.query.tag ? req.query.tag : '精选';
  cache.apiGetMoviesByRedis(tag, function(err, results) {
    if(err) {
      console.log(err);
    }
    var lists = [];
    lists = lists.concat(results.movies, results.tvs);
    lists = _.sortBy(lists, function(list) {
      return -list.createAt;
    });
    const newmovies = lists;
    let hotmovies = [];
    hotmovies = hotmovies.concat(results.hotmovies, results.hottvs);
    let randommovies = [];
    randommovies = randommovies.concat(results.randommovies, results.randomtvs);
    let pushmovies = results.pushmovies;
    return res.json({success:1, randommovies, hotmovies, newmovies, pushmovies});
  })
};
exports.apigetplay = function(req, res) {
  var page = req.query.page > 0 ? req.query.page : 1;
  var perPage = req.query.counts > 0 ? req.query.counts * 1 : 20;
  var id = req.query.id;
  async.parallel(
    {
      movies: function(callback) {
        Movie.find({ status: 'finished' })
          .sort('-count')
          .limit(perPage)
          .skip(perPage * (page - 1))
          .exec(function(err, movies) {
            if (err) {
              callback(err, null);
            }
            callback(null, movies);
          });
      },
      movie: function(callback) {
        Movie.findOne({ _id: id }).exec(function(err, movie) {
          if (err) {
            callback(err, null);
          }
          callback(null, movie);
        });
      },
      token: function(callback) {
        cache.getTokenByRedis(function(err, token) {
          if (err) {
            callback(err, null);
          }
          callback(null, token);
        });
      }
    },
    function(err, results) {
      if (err) {
        return res.json({
          error: err
        });
      }
      var m3u8 = '/videos/' + id + '/index.m3u8';
      res.json({
        movies: results.movies,
        m3u8: m3u8,
        movie: results.movie,
        token: results.token
      });
    }
  );
};
exports.apigetmoviestab = function(req, res) {
  var page = req.query.page > 0 ? req.query.page : 1;
  var perPage = req.query.counts > 0 ? req.query.counts * 1 : 20;
  var sort = req.query.sort ? req.query.sort : 'newtime';
  var tab = req.query.tab ? req.query.tab : 'all';
  var query = {};
  if (tab == 'all') {
    query = { status: 'finished' };
  } else {
    query = { status: 'finished', category: tab };
  }
  var sortquery = '';
  if (sort == 'hot') {
    sortquery = '-count';
  } else if (sort == 'nothot') {
    sortquery = 'count';
  } else if (sort == 'newtime') {
    sortquery = '-createAt';
  } else if (sort == 'oldtime') {
    sortquery = 'createAt';
  }
  async.parallel(
    {
      movies: function(callback) {
        Movie.find(query)
          .sort(sortquery)
          .limit(perPage)
          .skip(perPage * (page - 1))
          .exec(function(err, movies) {
            if (err) {
              callback(err, null);
            }
            callback(null, movies);
          });
      },
      tabs: function(callback) {
        Category.find().exec(function(err, tabs) {
          if (err) {
            callback(err, null);
          }
          callback(null, tabs);
        });
      }
    },
    function(err, results) {
      if (err) {
        return res.json({
          error: err
        });
      }
      res.json({
        movies: results.movies,
        tabs: results.tabs
      });
    }
  );
};
exports.apigetsearch = function(req, res) {
  var page = req.query.page > 0 ? req.query.page : 1;
  var perPage = req.query.counts > 0 ? req.query.counts * 1 : 20;
  var q = req.query.q > 0 ? req.query.q : '';
  var reg = new RegExp(q, 'i');
  Movie.find({ originalname: reg })
    .limit(perPage)
    .skip(perPage * (page - 1))
    .exec(function(err, movies) {
      if (err) {
        res.json({
          error: err,
          movies: null
        });
      }
      res.json({
        movies: movies
      });
    });
};
exports.getmoviesbytag = async (req, res) => {
  var tag = req.params.tag;
  var page = req.query.page > 0 ? req.query.page : 1;
  var perPage = 12;
  const moviecount = await Movie.countDocuments({
    $or: [
      { director: tag },
      { stars: tag },
      { writer: tag },
      { country: tag },
      { tags: tag }
    ]
  });
  const movies = await Movie.find({
    $or: [
      { director: tag },
      { stars: tag },
      { writer: tag },
      { country: tag },
      { tags: tag }
    ]
  })
    .where({ status: 'finished' })
    .sort('-createAt')
    .limit(perPage)
    .skip(perPage * (page - 1));
  const tvcount = await Tv.countDocuments({
    $or: [
      { director: tag },
      { stars: tag },
      { writer: tag },
      { country: tag },
      { tags: tag }
    ]
  });
  const tvs = await Tv.find({
    $or: [
      { director: tag },
      { stars: tag },
      { writer: tag },
      { country: tag },
      { tags: tag }
    ]
  })
    .sort('-createAt')
    .limit(perPage)
    .skip(perPage * (page - 1));
  const count = moviecount > tvcount ? moviecount : tvcount;
  let lists = [];
  lists = lists.concat(movies, tvs);
  lists = _.sortBy(lists, function(list) {
    return -list.createAt;
  });
  res.render(req.portal.theme + '/tag', {
    title: tag,
    tag: tag,
    lists,
    portal: req.portal,
    page: page,
    user: req.session.leveluser,
    pages: Math.ceil(count / perPage)
  });
};
exports.taggroup = async (req, res) => {
  var id = req.params.id;
  var page = req.query.page > 0 ? req.query.page : 1;
  var perPage = 200;
  const count = await Tag.find({ groupid: id });
  Tag.find({ groupid: id })
    .sort('-counts')
    .limit(perPage)
    .skip(perPage * (page - 1))
    .exec(function(err, tags) {
      if (err) {
        console.log(err);
      }
      Taggroup.findOne({ _id: id }).exec(function(err, group) {
        if (err) {
          console.log(err);
        }
        res.render(req.portal.theme + '/taggroup', {
          title: group.title + '列表查询',
          group: group,
          tags: tags,
          page: page,
          user: req.session.leveluser,
          pages: Math.ceil(count / perPage),
          portal: req.portal
        });
      });
    });
};
exports.getalltags = function(req, res) {
  Taggroup.find().exec(function(err, groups) {
    if (err) {
      console.log(err);
    }
    Tag.find()
      .sort('-counts')
      .limit(300)
      .exec(function(err, tags) {
        if (err) {
          console.log(err);
        }
        res.render(req.portal.theme + '/tags', {
          title: '热门动漫分类',
          tags: tags,
          groups: groups,
          portal: req.portal,
          user: req.session.leveluser
        });
      });
  });
};
exports.getuser = async function(req, res) {
  const user = await User.findOne({ username: req.params.name }).populate(
    'group vipgroup.groupid'
  );
  const duedate = moment(user.vipgroup.duedate).format(
    'YYYY年MM月DD日, HH:mm:ss'
  );
  res.render(req.portal.theme + '/user', {
    title: user.username + '个人页面',
    user: req.session.leveluser,
    theuser: user,
    duedate,
    portal: req.portal
  });
};
exports.invite = async function(req, res) {
  let ip = req.ip.match(/\d+\.\d+\.\d+\.\d+/);
  if (!ip) {
    ip = '0.0.0.0';
  } else {
    ip = ip[0];
  }
  const id = req.query.id;
  const user = await User.findById(id).populate('group');
  const groups = await Group.find();
  if (user) {
    const invite = await Invite.findOne({ uid: id });
    let score = user.score;
    let usergroup = user.group;
    if (invite) {
      if (invite.invite.indexOf(ip) > -1) {
        return res.redirect('/');
      } else {
        score += 1;
        for (let index = 0; index < groups.length; index++) {
          const group = groups[index];
          if (group.score <= score) {
            usergroup = group;
          }
        }
        let update = {
          group: usergroup,
          score: score
        };
        await User.updateOne({ _id: id }, { $set: update });
        await Invite.updateOne({ _id: invite._id }, { $push: { invite: ip } });
        req.session.leveluser.group = usergroup;
        return res.redirect('/');
      }
    } else {
      score += 1;
      for (let index = 0; index < groups.length; index++) {
        const group = groups[index];
        if (group.score <= score) {
          usergroup = group;
        }
      }
      let update = {
        group: usergroup,
        score: score
      };
      await User.updateOne({ _id: id }, { $set: update });
      await Invite.create({ uid: id, invite: [ip] });
      req.session.leveluser.group = usergroup;
      return res.redirect('/');
    }
  }
  res.redirect('/');
};
exports.getthemovie = async (req, res) => {
  const id = req.query.id;
  const movie = await Movie.findById(id);
  if(movie) {
    return res.json({success:1, movie});
  }
  return res.json({success:0});
}
exports.apitgetthetv = async (req, res) => {
  const id = req.query.id;
  const movie = await Movie.findById(id);
  const tv = await Tv.findById(movie.totv);
  if(movie&&tv) {
    return res.json({success:1, movie, tv});
  }
  return res.json({success:0});
}
exports.apigetmovie = async function(req, res) {
  var type = req.query.type ? parseInt(req.query.type) : 320;
  var id = req.query.id;
  var group = await Group.findOne({ permission: type });
  var user = req.session.leveluser;
  var movie = await Movie.findById(id);
  if(!group) {
    return res.status(404).send('未设置正确用户组');
  }
  if (!movie) {
    return res.status(404).send('对不起，无此电影。');
  }
  var paths = _.find(movie.m3u8paths, function(path) {
    return path.hd == type;
  });
  if (!paths) {
    res.status(404);
    return res.send('对不起参数错误。');
  }
  var m3u8 = paths.path.replace('./public', '');
  const portal = await Portal.findOne();
  if(portal.shikan=='on') {
    if (user) {
      const theuser = await User.findById(user._id).populate(
        'group vipgroup.groupid'
      );
      if (theuser.group.permission >= type) {
        return res.json({ m3u8 });
      } else {
        if (theuser.vipgroup.groupid) {
          if (
            theuser.vipgroup.groupid.permission >= type &&
            moment(theuser.vipgroup.duedate).isAfter(Date.now())
          ) {
            return res.json({ m3u8 });
          } else {
            return res.json({
              m3u8,
              message:
                '对不起，您的用户组只能试看一分钟，请升级。'
            });
          }
        }
        return res.json({
          m3u8,
          message:
            '对不起，您的用户组只能试看一分钟，请升级。'
        });
      }
    } else {
      return res.json({
        m3u8,
        message: '对不清，您未登录，只能试看一分钟，请登录'
      })
    }
  } else {
    if (group.score == 0) {
      return res.json({ m3u8 });
    } else {
      if (user) {
        const theuser = await User.findById(user._id).populate(
          'group vipgroup.groupid'
        );
        if (theuser.group.permission >= type) {
          return res.json({ m3u8 });
        } else {
          if (theuser.vipgroup.groupid) {
            if (
              theuser.vipgroup.groupid.permission >= type &&
              moment(theuser.vipgroup.duedate).isAfter(Date.now())
            ) {
              return res.json({ m3u8 });
            } else {
              return res.json({
                message:
                  '切换分辨率失败，用户组权限不够或过期，前往个人中心推广升级。'
              });
            }
          }
          return res.json({
            message:
              '切换分辨率失败，用户组权限不够或过期，前往个人中心推广升级。'
          });
        }
      } else {
        return res.json({ message: '对不起，您未登录，不能切换分辨率。' });
      }
    }
  }
}
exports.apigetm3u8 = async function(req, res) {
  var type = req.query.type ? parseInt(req.query.type) : 320;
  var id = req.query.id;
  var group = await Group.findOne({ permission: type });
  const token = req.query.token;
  var movie = await Movie.findById(id);
  if(!group) {
    return res.json({success:0, message: '对不起，没有正确设置用户组。'});
  }
  if (!movie) {
    return res.json({success:0, message:'没有此电影。'});
  }
  var paths = _.find(movie.m3u8paths, function(path) {
    return path.hd == type;
  });
  if (!paths) {
    res.status(404);
    return res.send('对不起参数错误。');
  }
  var m3u8 = paths.path.replace('./public', '');
  const portal = await Portal.findOne();
  jwt.verify(token, req.apikey, async function(err, decoded) {
    if(err) {
      return res.json({success:0, message: '对不起，请重新登录'})
    }
    const id = decoded.id;
    const user = await User.findById(id).populate(
      'group vipgroup.groupid'
    );
    if(portal.shikan=='on') {
      if (user.group.permission >= type) {
        return res.json({success:1,  m3u8 });
      } else {
        if (user.vipgroup.groupid) {
          if (
            user.vipgroup.groupid.permission >= type &&
            moment(user.vipgroup.duedate).isAfter(Date.now())
          ) {
            return res.json({ success: 1, m3u8 });
          } else {
            return res.json({
              success: 0,
              m3u8,
              message:
                '对不起，您的用户组只能试看一分钟，请升级。'
            });
          }
        }
        return res.json({
          success: 0,
          m3u8,
          message:
            '对不起，您的用户组只能试看一分钟，请升级。'
        });
      }
    } else {
      if (group.score == 0) {
        return res.json({ success: 1, m3u8 });
      } else {
        if (user.group.permission >= type) {
          return res.json({ success: 1, m3u8 });
        } else {
          if (user.vipgroup.groupid) {
            if (
              user.vipgroup.groupid.permission >= type &&
              moment(user.vipgroup.duedate).isAfter(Date.now())
            ) {
              return res.json({ success: 1, m3u8 });
            } else {
              return res.json({
                success: 0,
                message:
                  '切换分辨率失败，用户组权限不够或过期，前往个人中心推广升级。'
              });
            }
          }
          return res.json({
            success: 0,
            message:
              '切换分辨率失败，用户组权限不够或过期，前往个人中心推广升级。'
          });
        }
      }
    }
  })
};
exports.buyvip = async function(req, res) {
  const vipgroups = await Vipuser.find();
  res.render(req.portal.theme + '/buyvip', {
    title: '积分购买VIP用户组',
    portal: req.portal,
    vipgroups,
    user: req.session.leveluser,
    info: req.flash('info')
  });
};
exports.postbuyvip = async (req, res) => {
  const { vipgroup, duration } = req.body;
  if (vipgroup && duration) {
    const vipbuy = await Vipbuy.findOne({ group: vipgroup, duration });
    if (!vipbuy) {
      req.flash('info', '对不起，您所选的套餐暂时无法购买');
      return res.redirect('/buyvip');
    } else {
      const user = await User.findById(req.session.leveluser._id);
      if (user.score < vipbuy.score) {
        req.flash('info', '对不起，您的积分不足以购买此套餐');
        return res.redirect('/buyvip');
      } else {
        var duedate = user.duedate;
        var score = user.score - vipbuy.score;
        var groupid = vipbuy.group;
        if (duedate && moment(duedate).isAfter(Date.now())) {
          duedate = moment(duedate).add(vipbuy.duration, 'days');
        } else {
          duedate = moment().add(vipbuy.duration, 'days');
        }
        var update = {
          groupid,
          duedate
        };
        await User.updateOne(
          { _id: user._id },
          { $set: { score, vipgroup: update } }
        );
        req.flash('info', '恭喜，您已经购买成功。');
        return res.redirect('/buyvip');
      }
    }
  } else {
    req.flash('info', '对不起，您的参数选择错误');
    return res.redirect('/buyvip');
  }
};
exports.getjiage = async (req, res) => {
  const { group, duration } = req.query;
  const vipbuy = await Vipbuy.findOne({ group, duration });
  if (!vipbuy) {
    res.json({ score: '对不起暂时无法购买' });
  } else {
    res.json({ score: vipbuy.score });
  }
};
exports.getmianzhi = async (req, res) => {
  const card = req.query.card;
  const thecard = await Card.findOne({ card, status: 'notuse' });
  if (thecard) {
    res.json({ mianzhi: thecard.score });
  } else {
    res.json({ mianzhi: '对不起，卡卷输入错误或者已经被使用' });
  }
};
exports.playm3u8 = async function(req, res) {
  const m3u8 = req.query.m3u8;
  const setting = await Setting.findOne();
  res.render('m3u8', {
    m3u8,
    antiurl: setting.antiurl
  });
};
exports.userupload = function(req, res) {
  res.render(req.portal.theme + '/userupload', {
    title: '上传页面',
    portal: req.portal,
    user: req.session.leveluser,
    info: req.flash('info')
  });
};
exports.postuserupload = async (req, res) => {
  var file = req.file;
  var body = req.body;
  var des = './movies/';
  var filename = file.originalname;
  var filearr = filename.split('.');
  filearr.pop();
  var path = filearr.join('.');
  var tmppath = des + path;
  var exitst = fs.existsSync(tmppath);
  if (!exitst) {
    fs.mkdirSync(tmppath);
  }
  var newfilename = filename + body.chunk;
  fs.renameSync(file.path, tmppath + '/' + newfilename);
  if (body.chunk * 1 + 1 == body.chunks * 1) {
    var files = fs.readdirSync(tmppath);
    for (var i = 0; i < files.length; i++) {
      fs.appendFileSync(
        file.path + '',
        fs.readFileSync(tmppath + '/' + filename + i)
      );
      fs.unlinkSync(tmppath + '/' + filename + i);
    }
    fs.rmdirSync(tmppath);
    var movieObj = {
      status: '审核',
      originalname: file.originalname,
      path: file.path,
      size: body.size,
      md5: body.filemd5
    };
    const movie = await Movie.create(movieObj);
    await Userupload.create({
      userid: req.session.leveluser._id,
      movieid: movie._id
    });
  }
  return res.json({ success: 1 });
};
exports.useruploads = async (req, res) => {
  var page = req.query.page > 0 ? req.query.page : 1;
  var perPage = 12;
  const id = req.params.id;
  if(id != req.session.leveluser._id) {
    return res.status(404).send('没有此页面');
  }
  const count = await Userupload.countDocuments({
    userid: req.session.leveluser._id
  });
  const useruploads = await Userupload.find({
    userid: req.session.leveluser._id
  })
    .populate('movieid')
    .sort('-createAt')
    .limit(perPage)
    .skip(perPage * (page - 1));
  res.render(req.portal.theme + '/useruploads', {
    title: '我上传的视频',
    portal: req.portal,
    useruploads,
    user: req.session.leveluser,
    pages: Math.ceil(count / perPage),
    info: req.flash('info')
  });
};
function deleteall(path) {
  var files = [];
  if (fs.existsSync(path)) {
    files = fs.readdirSync(path);
    files.forEach(function(file, index) {
      var curPath = path + '/' + file;
      if (fs.statSync(curPath).isDirectory()) {
        // recurse
        deleteall(curPath);
      } else {
        // delete file
        fs.unlinkSync(curPath);
      }
    });
    fs.rmdirSync(path);
  }
}
exports.payback = async (req, res) => {
  const body = req.body;
  const response = await alipay.check(body);
  if (response == 'success') {
    res.send('success');
  } else {
    res.send('failure');
  }
};
exports.adminpay = async (req, res) => {
  const pay = await Pay.findOne();
  res.render('adminpay', { pay });
};
exports.postadminpay = async (req, res) => {
  const { appid, privatekey, publickey } = req.body;
  const pay = await Pay.findOne();
  const des = './key/';
  const privatepem = des + 'private-key.pem';
  const publicpem = des + 'public-key.pem';
  const privateexsit = fs.existsSync(privatepem);
  const publicexsit = fs.existsSync(publicpem);
  if (privateexsit) {
    fs.unlinkSync(privatepem);
  }
  if (publicexsit) {
    fs.unlinkSync(publicpem);
  }
  fs.writeFileSync(privatepem, privatekey.trim());
  fs.writeFileSync(publicpem, publickey.trim());
  if (!pay) {
    await Pay.create({ appid, privatekey, publickey });
    return res.redirect('/admin/pay');
  } else {
    await Pay.updateOne(
      { _id: pay._id },
      { $set: { appid, privatekey, publickey } }
    );
    return res.redirect('/admin/pay');
  }
};
exports.buyscore = (req, res) => {
  res.render(req.portal.theme + '/buyscore', {
    title: '购买积分',
    portal: req.portal,
    user: req.session.leveluser,
    info: req.flash('info')
  });
};
exports.postbuyscore = async (req, res) => {
  const score = req.body.score;
  const danjia = req.portal.amount;
  const user = req.session.leveluser;
  const amount = score * danjia;
  const subject = '购买' + score + '点积分';
  const item = await Item.create({
    uid: user._id,
    subject,
    score,
    amount: amount.toFixed(2),
    status: 'notpay'
  });
  res.redirect('/item/' + item._id);
};
exports.getitem = async (req, res) => {
  const item = await Item.findById(req.params.id);
  res.render(req.portal.theme + '/item', {
    title: item.subject,
    portal: req.portal,
    item,
    user: req.session.leveluser,
    info: req.flash('info')
  });
};

exports.postitem = async (req, res) => {
  const id = req.params.id;
  const item = await Item.findById(id).populate('uid');
  const setting = await Setting.findOne();
  const deviceAgent = req.headers['user-agent'].toLowerCase();
  const agentID = deviceAgent.match(/(iphone|ipod|ipad|android)/);
  let type = 'page';
  if (agentID) {
    type = 'wap';
  } else {
    type = 'page';
  }
  const url = await alipay.pagepay({
    notifyurl: setting.host + '/payback',
    returnurl: setting.host + '/user/' + item.uid.username,
    outtradeno: id,
    totalamount: item.amount,
    subject: item.subject,
    type: type
  });
  if (url) {
    res.json({
      done: 1,
      payurl: url
    });
  }
};

exports.adminitem = async (req, res) => {
  let page = req.query.page > 0 ? req.query.page : 1;
  let perPage = 50;
  const items = await Item.find()
    .populate('uid')
    .sort('-createAt')
    .limit(perPage)
    .skip(perPage * (page - 1));
  const count = await Item.find();
  res.render('adminitem', {
    title: '订单管理',
    items,
    page: page,
    pages: Math.ceil(count / perPage)
  });
};
exports.hots = async (req, res) => {
  const perPage = 15;
  const now = new Date();
  const month = new Date(now.getTime() - 30 * 24 * 3600 * 1000);
  const year = new Date(now.getTime() - 365 * 24 * 3600 * 1000);
  const week = new Date(now.getTime() - 7 * 24 * 3600 * 1000);
  const tvfind = {'episodes.0': {$exists: 1}};
  const monthhotmovies = await Movie.find({status: 'finished'})
     .where('createAt').gt(month)
     .sort('-count')
     .limit(perPage)
  const monthhottvs = await Tv.find(tvfind)
     .where('createAt').gt(month)
     .sort('-count')
     .limit(perPage);
  const yearhotmovies = await Movie.find({status: 'finished'})
     .where('createAt').gt(year)
     .sort('-count')
     .limit(perPage)
  const yearhottvs = await Tv.find(tvfind)
     .where('createAt').gt(year)
     .sort('-count')
     .limit(perPage);
  const weekhotmovies = await Movie.find({status: 'finished'})
     .where('createAt').gt(week)
     .sort('-count')
     .limit(perPage)
  const weekhottvs = await Tv.find(tvfind)
     .where('createAt').gt(week)
     .sort('-count')
     .limit(perPage);
  let monthmovies = [];
  monthmovies = monthmovies.concat(monthhotmovies, monthhottvs);
  monthmovies = _.sortBy(monthmovies, function(list) {
    return -list.count;
  });
  let yearmovies = [];
  yearmovies = yearmovies.concat(yearhotmovies, yearhottvs);
  yearmovies = _.sortBy(yearmovies, function(list) {
    return -list.count;
  });
  let weekmovies = [];
  weekmovies = weekmovies.concat(weekhotmovies, weekhottvs);
  weekmovies = _.sortBy(weekmovies, function(list) {
    return -list.count;
  });
  return res.render(req.portal.theme + '/hots', {
    title: '热门',
    portal: req.portal,
    weekmovies,
    yearmovies,
    monthmovies,
    user: req.session.leveluser,
  })
}
exports.random = async (req, res) => {
  const tvfind = {'episodes.0': {$exists: 1}};
  const moviescount = await Movie.countDocuments().where({status: 'finished'});
  const tvcount = await Tv.countDocuments(tvfind);
  let movieskip = Math.floor(Math.random() * (moviescount - 12));
  let tvskip = Math.floor(Math.random * (tvcount - 12 ));
  if (movieskip < 0) {
    movieskip = 0;
  }
  if (tvskip < 0) {
    tvskip = 0;
  }
  const movies = await Movie.find({status: 'finished'})
      .limit(12)
      .skip(movieskip)
  const tvs = await Tv.find(tvfind).limit(12).skip(tvskip);
  var lists = [];
  lists = lists.concat(movies, tvs);
  lists = _.shuffle(lists);
  const randommovies = lists;
  return res.render(req.portal.theme + '/random', {
    title: '随便看看',
    portal: req.portal,
    user: req.session.leveluser,
    randommovies,
  })
}
exports.getedituser = async (req, res) => {
  const id = req.params.id;
  const user = req.session.leveluser;
  if(user._id != id) {
    return res.send('对不起，此页面不存在!');
  }
  return res.render(req.portal.theme + '/edituser', {
    title: '修改用户资料',
    portal: req.portal,
    user: req.session.leveluser,
    info: req.flash('info')
  })
}
exports.apipostcomment = async (req, res) => {
  const {content, id} = req.body;
  const user = req.session.leveluser;
  const portal = await Portal.findOne();
  let status = 'shenhe';
  let message = '';
  if(portal.shenhe=='on') {
    status = 'shenhe';
    message = '恭喜您，发布评论成功，评论进入审核区，审核通过即可看见。';
  } else {
    status = "published";
    message = '恭喜您，发布评论成功！';
  }
  if(content&&id) {
    await Comment.create({content, movieid: id, uid: user._id, status});
    return res.json({success: 1, message})
  }
  res.json({success:0, message:'发布了意想不到的错误!'});
}
exports.postedituser = async (req, res) => {
  const id = req.params.id;
  const user = req.session.leveluser;
  const {oldpassword, newpassword} = req.body;
  if(user._id != id) {
    return res.send('对不起，此页面不存在!');
  }
  const md5 = crypto.createHash('md5');
  const theoldpassword = md5.update(oldpassword).digest('hex');
  const theuser = await User.findOne({ password: theoldpassword, _id:id });
  if(theuser) {
    const newmd5 = crypto.createHash('md5');
    const thenewpassword = newmd5.update(newpassword).digest('hex');
    await User.updateOne({_id: id}, {$set: {password: thenewpassword}});
    req.session.leveluser = null;
    return res.redirect('/login');
  }
  req.flash('info', '对不起，原来的密码输入错误，请重试。');
  return res.redirect('/user/'+id + '/edit');
}
exports.apipostmovie = async (req, res) => {
  const {originalname,originaltitle, aka,
    language, banben, director, stars,writer,
    summary,country,tags,year,rate,duration,path,size} = req.body;
  var thetags = [];
  var directorarr = director.split(',');
  var starsarr = stars.split(',');
  var writerarr = writer.split(',');
  var countryarr = country.split(',');
  var thetagsarr = tags.split(',');
  thetags = thetags.concat(
    directorarr,
    starsarr,
    writerarr,
    countryarr,
    thetagsarr
  );
  thetags = _.uniq(thetags);
  thetags.forEach(val => {
    Tag.findOne({ tag: val }).exec(function(err, tag) {
      if (err) {
        console.log(err);
      }
      if (tag) {
        tag.counts += 1;
        tag.save(function(err) {
          if (err) {
            console.log(err);
          }
        });
      } else {
        Tag.create({ tag: val }, function(err) {
          if (err) {
            console.log(err);
          }
        });
      }
    });
  });
  await Movie.create({path, status:'waiting',originalname, originaltitle,aka, language,banben,
    director: directorarr,writer:writerarr, stars:starsarr,summary,country:countryarr,tags:thetagsarr,
    year,rate,duration,size, createAt: new Date()});
  res.json({
    success:1
  });
}