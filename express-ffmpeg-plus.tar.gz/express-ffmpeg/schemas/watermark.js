var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var WatermarkSchema = new Schema({
  path: String,
  place: String,
  createAt: {
    type: Date
  }
});
WatermarkSchema.pre('save', function(next) {
  if (!this.createAt) {
    this.createAt = Date.now();
  }
  next();
});
module.exports = WatermarkSchema;
