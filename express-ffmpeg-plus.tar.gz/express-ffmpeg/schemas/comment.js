var mongoose = require("mongoose")
var Schema = mongoose.Schema
var CommentSchema = new Schema({
  uid: { type: Schema.Types.ObjectId, ref: "User" },
  content: String,
  status: { type: String, default: 'shenhe' },
  movieid: { type: Schema.Types.ObjectId, ref: 'Movie' },
  createAt: {
    type: Date
  }
})
CommentSchema.pre("save", function(next) {
  if (!this.createAt) {
    this.createAt = Date.now()
  }
  next()
})
module.exports = CommentSchema
