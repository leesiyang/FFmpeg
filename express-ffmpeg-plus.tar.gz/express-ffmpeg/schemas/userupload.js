var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var UseruploadSchema = new Schema({
  userid: { type: Schema.Types.ObjectId, ref: 'User' },
  movieid: { type: Schema.Types.ObjectId, ref: 'Movie' },
  createAt: {
    type: Date
  }
});
UseruploadSchema.pre('save', function(next) {
  if (!this.createAt) {
    this.createAt = Date.now();
  }
  next();
});
module.exports = UseruploadSchema;
