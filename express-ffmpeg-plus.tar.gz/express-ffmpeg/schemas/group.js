var mongoose = require("mongoose")
var Schema = mongoose.Schema
var GroupSchema = new Schema({
  title: String,
  permission: Number,
  score: Number,
  createAt: {
    type: Date
  }
})
GroupSchema.pre("save", function(next) {
  if (!this.createAt) {
    this.createAt = Date.now()
  }
  next()
})
module.exports = GroupSchema
