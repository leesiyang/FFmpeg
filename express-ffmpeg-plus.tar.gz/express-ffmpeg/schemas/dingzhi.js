var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var DingzhiSchema = new Schema({
  movieid: { type: Schema.Types.ObjectId },
  hds: [Number],
  rate: String,
  keepmp4: [Number],
  isqiepian: String,
  createAt: {
    type: Date,
    default: Date.now()
  }
});
DingzhiSchema.pre('save', function(next) {
  if (!this.createAt) {
    this.createAt = Date.now();
  }
  next();
});
module.exports = DingzhiSchema;
