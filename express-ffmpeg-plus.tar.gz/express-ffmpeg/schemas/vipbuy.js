var mongoose = require("mongoose")
var Schema = mongoose.Schema
var VipbuySchema = new Schema({
  group: { type: Schema.Types.ObjectId, ref: "Vipuser" },
  duration: Number,
  score: Number,
  createAt: {
    type: Date
  }
})
VipbuySchema.pre("save", function(next) {
  if (!this.createAt) {
    this.createAt = Date.now()
  }
  next()
})
module.exports = VipbuySchema
