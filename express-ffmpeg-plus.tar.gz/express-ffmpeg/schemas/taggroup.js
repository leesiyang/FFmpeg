var mongoose = require("mongoose")
var Schema = mongoose.Schema
var TaggroupSchema = new Schema({
  title: String,
  seotitle: String,
  createAt: {
    type: Date
  }
})
TaggroupSchema.pre("save", function(next) {
  if (!this.createAt) {
    this.createAt = Date.now()
  }
  next()
})
module.exports = TaggroupSchema
