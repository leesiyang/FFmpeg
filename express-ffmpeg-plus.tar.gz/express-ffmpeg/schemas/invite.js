var mongoose = require("mongoose")
var Schema = mongoose.Schema
var InviteSchema = new Schema({
  uid: { type: Schema.Types.ObjectId, ref: "User" },
  invite: [String],
  createAt: {
    type: Date
  }
})
InviteSchema.pre("save", function(next) {
  if (!this.createAt) {
    this.createAt = Date.now()
  }
  next()
})
module.exports = InviteSchema
