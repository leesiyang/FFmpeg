var mongoose = require("mongoose")
var Schema = mongoose.Schema
var VipuserSchema = new Schema({
  title: String,
  permission: Number,
  createAt: {
    type: Date
  }
})
VipuserSchema.pre("save", function(next) {
  if (!this.createAt) {
    this.createAt = Date.now()
  }
  next()
})
module.exports = VipuserSchema
