var mongoose = require("mongoose")
var Schema = mongoose.Schema
var TvSchema = new Schema({
  title: String,
  originaltitle: String,
  aka: String,
  poster: String,
  count: { type: Number, default: 0 },
  duration: String,
  director: [String],
  writer: [String],
  rate: String,
  year: Number,
  language: String,
  episodescount: String,
  stars: [String],
  summary: String,
  country: [String],
  tags: [String],
  status: String,
  zhouqi: String,
  episodes: [{ episode: String, movieid: Schema.Types.ObjectId }],
  createAt: {
    type: Date
  }
})
TvSchema.pre("save", function(next) {
  if (!this.createAt) {
    this.createAt = Date.now()
  }
  next()
})
TvSchema.index({ director: 1 })
TvSchema.index({ stars: 1 })
TvSchema.index({ writer: 1 })
TvSchema.index({ country: 1 })
TvSchema.index({ tags: 1 })
TvSchema.index({ title: 1, createAt: -1 })
module.exports = TvSchema
