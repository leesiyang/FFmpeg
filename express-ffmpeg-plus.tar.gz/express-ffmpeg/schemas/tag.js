var mongoose = require("mongoose")
var Schema = mongoose.Schema
var TagSchema = new Schema({
  tag: String,
  groupid: { type: Schema.Types.ObjectId, ref: "Taggroup" },
  counts: { type: Number, default: 1 },
  createAt: {
    type: Date
  }
})
TagSchema.pre("save", function(next) {
  if (!this.createAt) {
    this.createAt = Date.now()
  }
  next()
})
module.exports = TagSchema
