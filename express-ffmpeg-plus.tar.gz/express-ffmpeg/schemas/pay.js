var mongoose = require("mongoose")
var Schema = mongoose.Schema
var PaySchema = new Schema({
  appid: String,
  privatekey:String,
  publickey: String,
  createAt: {
    type: Date
  }
})
PaySchema.pre("save", function(next) {
  if (!this.createAt) {
    this.createAt = Date.now()
  }
  next()
})
module.exports = PaySchema
