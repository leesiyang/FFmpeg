var mongoose = require("mongoose")
var Schema = mongoose.Schema
var ItemSchema = new Schema({
  uid: { type: Schema.Types.ObjectId, ref: "User" },
  subject: String,
  score: Number,
  amount: String,
  status: String,
  createAt: {
    type: Date
  }
})
ItemSchema.pre("save", function(next) {
  if (!this.createAt) {
    this.createAt = Date.now()
  }
  next()
})
module.exports = ItemSchema
